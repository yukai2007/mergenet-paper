# Third-party attribution

This implementation builds on OpenToMe, ToMe, DTEM, timm, and FlashAttention. Original third-party copyright notices and references are retained in the source and LICENSE. These attributions describe upstream software and do not identify this submission's authors.
